---
name: Pro-Culinary Management System
colors:
  surface: '#f1fbff'
  surface-dim: '#d1dce0'
  surface-bright: '#f1fbff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eaf5fa'
  surface-container: '#e4f0f4'
  surface-container-high: '#dfeaef'
  surface-container-highest: '#d9e4e9'
  on-surface: '#131d21'
  on-surface-variant: '#594138'
  inverse-surface: '#283236'
  inverse-on-surface: '#e7f3f7'
  outline: '#8d7166'
  outline-variant: '#e1bfb3'
  surface-tint: '#a63b00'
  primary: '#a63b00'
  on-primary: '#ffffff'
  primary-container: '#f26522'
  on-primary-container: '#4f1800'
  inverse-primary: '#ffb599'
  secondary: '#586062'
  on-secondary: '#ffffff'
  secondary-container: '#dae1e3'
  on-secondary-container: '#5d6466'
  tertiary: '#006b55'
  on-tertiary: '#ffffff'
  tertiary-container: '#00a484'
  on-tertiary-container: '#003125'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb599'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#7f2b00'
  secondary-fixed: '#dde4e6'
  secondary-fixed-dim: '#c1c8ca'
  on-secondary-fixed: '#161d1f'
  on-secondary-fixed-variant: '#41484a'
  tertiary-fixed: '#6dfad2'
  tertiary-fixed-dim: '#4bddb7'
  on-tertiary-fixed: '#002018'
  on-tertiary-fixed-variant: '#005140'
  background: '#f1fbff'
  on-background: '#131d21'
  surface-variant: '#d9e4e9'
typography:
  h1:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  h2:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  h3:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
  status-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 20px
  container-padding: 24px
---

## Brand & Style
The brand personality of the design system is efficient, energetic, and professional. It targets restaurant owners and staff who require a tool that balances high-speed utility with an inviting aesthetic. The UI evokes a sense of reliability and appetite through its "Corporate Modern" style, utilizing a clean, white-space-heavy layout that allows food imagery and critical action colors to stand out. The experience is designed to be "airy," reducing cognitive load in high-pressure kitchen and floor environments.

## Colors
The palette is centered around a vibrant orange (#F26522), used exclusively for primary actions and brand touchpoints to drive focus. 
- **Primary:** Orange is used for buttons, active states, and highlights.
- **Surface:** Pure white (#FFFFFF) for cards and primary backgrounds to maintain a "clean" look.
- **Semantic:** 
  - **Stock/Critical:** A bold red for low stock and urgent alerts.
  - **Stock/Optimal:** A fresh green for healthy inventory and "Ready" orders.
  - **Stock/Warning / In-Process:** A warm amber for items needing attention soon or active cooking.
- **Neutrals:** Soft greys are used for borders and secondary text to ensure the orange remains the focal point.

## Typography
This design system uses **Plus Jakarta Sans** for its modern, friendly, and highly legible geometric terminals. The hierarchy is established through significant weight shifts.
- **Headlines:** Use Bold (700) and Semi-Bold (600) for instant recognition of categories and titles.
- **Body:** Uses a Regular weight (400) with generous line heights to ensure readability in moving environments.
- **Labels:** Small caps or bolded labels are used for input headers and metadata to provide structure without clutter.

## Layout & Spacing
The layout follows a **fluid grid** model with a consistent 8px spacing rhythm. 
- **Margins:** A standard 24px container padding is applied to all screens to maintain an "airy" feel.
- **Grid:** Use a 12-column grid for desktop/tablet dashboard views and a single-column flow for mobile.
- **Sectioning:** Content is grouped into cards separated by 16px (md) or 24px (lg) gaps to prevent the UI from feeling cramped.

## Elevation & Depth
Depth is achieved through **Tonal Layers** and **Ambient Shadows**. 
- **Level 0 (Background):** The canvas uses the background_surface color.
- **Level 1 (Cards):** Main content cards are pure white with a very soft, diffused shadow (0px 4px 12px, 5% opacity black).
- **Level 2 (Interactive):** Elements that are being hovered or dragged increase shadow spread to indicate lift.
- **Overlays:** Modals and menus use a backdrop blur (12px) to keep the context of the kitchen or floor visible while focusing the user.

## Shapes
The design system utilizes **Rounded** (Level 2) geometry to feel approachable and modern.
- **Standard Cards/Inputs:** 0.5rem (8px) radius.
- **Large Cards/Images:** 1rem (16px) radius for food photography and main dashboard modules.
- **Pills:** 1.5rem (24px) for status badges (Stock/Order status) to distinguish them from interactive buttons.

## Components
- **Buttons:** Primary buttons use the Orange #F26522 background with white text and 8px rounded corners. Secondary buttons use a light grey stroke or background.
- **Cards:** List cards for roles, dishes, and ingredients must include a clear trailing action or status indicator. Dish cards should feature a high-quality photo aspect ratio of 16:9 or 1:1.
- **Input Fields:** Outlined style with a 1px border. The label sits above the field in a bold, smaller font size. Focus state uses an orange border glow.
- **Status Badges:** 
  - **Stock:** Use a circle icon + text. Red (Critical), Amber (Low), Green (Optimal).
  - **Orders:** "In Process" uses an amber outline; "Ready" uses a solid green fill.
- **Icons:** Linear, 2px stroke weight. Icons should be sized at 24x24px for navigation and 16x16px for inline metadata.
- **Inventory List:** A specialized component showing a progress bar for "Stock Level" to provide a quick visual heat-map of the pantry.